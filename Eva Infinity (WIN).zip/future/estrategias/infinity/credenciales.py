# Inserta tus claves de API de BINANCE aquí
binance_api_key = 'ecUeMMrl2TkdMGCYddsQ48ouZGW8nNggvtGKD29DparKVUHy16MKPfDh2SFksWq2'
binance_api_secret = 'u5ZlU1SZfuYPxkxB8590tyYsVN8RaJawgvb8jhyRbOofVBSeHMYBdyi0nOlw3KOW'

# Inserta tus claves de API de ByBit futuros aquí
bybit_api_key = '1NCW0rD8IsNNbEAWp4'
bybit_api_secret = 'jg16h4DgUzNKw1tJp3U0IDpHcRQ8ELXR3c81'

# Inserta tus claves de API de ByBit (SUBCUENTA01) futuros aquí
bybit_subcuenta01_api_key = 'ow6RbnPWu90X8sErNX'
bybit_subcuenta01_api_secret = 'OPNvkoRqGiXp7QmcldzKGPuTZ6Q8QX0yOwhM'

# Inserta tus claves de API de BYBIT futuros aquí
bybit_subcuenta02_api_key = 'BagUl3MnSuParWWjdn'
bybit_subcuenta02_api_secret = 'pSjSB58qNlA7c5i1mUQaM72hyXQJQQwK6r29'

# Inserta tus claves de API de BYBIT futuros aquí
bybit_subcuenta03_api_key = 'm75CiXUhBLiyIPCOLb'
bybit_subcuenta03_api_secret = 'BScTn41mKCS3CvpMCScf9TYfOSEWiR4sfm97'

# Inserta tus claves de API de BITGET futuros aquí
bitget_api_key = "bg_5edea92dbb19848ce1729b19dee73de9"
bitget_api_secret = "9f35d204c277dd7aeaa04a0e8224161e152ff5b6a8371e032463f3f331ea347c"
bitget_api_passphrase = "Dios741236"

# Inserta tus claves de API de BINGX futuros aquí
bingx_api_key = 'FFLfUqt80Z1fZkE5p45fZes8WM3k31dCVtyetAHoGOQryPc6pxL1BMGbS9SJ1FFhHYaOE3pVLNppj9DSXl2Q'
bingx_api_secret = 'mAJanNvM1A6iqstBTZ43yPuoD9iBaO95DpSn4zFlWeuyFB9RCwftsFlxhlXgJkWu2NOI3RofTYqOqQfg'

# Inserta tus claves de API de OKX futuros aquí
okx_api_key = '7ff4849c-60f8-43f9-bc31-885791b3508a'
okx_api_secret = 'C20A4CAE73109A57F40895512A5FB50E'
okx_api_passphrase = "Dios741236$"

# Inserta tus claves de API de KUCOIN futuros aquí
kucoin_api_key = '6665d635e607490001c2cf35'
kucoin_api_secret = '592da144-7df5-4a92-9efc-5d2bdfabe068'
kucoin_api_passphrase = "dios741236"

# Inserta tus claves de API de GATE.io futuros aquí
gateio_api_key = '60e73f1c0b2b1cb131791f10537818c8'
gateio_api_secret = '7ba3069a6b3608fb1fd6f6333fc95e869d64d074992cbb70d8682688ee9c8289'

# Inserta tus claves de API de COINEX futuros aquí
coinex_api_key = 'C04145FBE3D04CB3A5021E00458C9E93'
coinex_api_secret = 'D5899D1B7EB7EFDE98DAE62B44E90BB0116D0265232FFDB0'